#ifndef __SENSOR_TYPE_H__
#define __SENSOR_TYPE_H__

#define TEMPERATURE         0xFF
#define HUMIDITY            0xFE
#define LIGHT_INTENSITY     0xFD

#endif //__SENSOR_TYPE_H__
