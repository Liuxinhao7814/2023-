#ifndef __LOWPOWER_H__
#define __LOWPOWER_H__
#include "main.h"

void Sleep_Mode();
void Stop_Mode();
void Awaken_SYSCLK();

#endif //__LOWPOWER_H__
